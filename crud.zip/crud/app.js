const http = require('http')
const express = require('express')
const app = express();
const url = 'mongodb://localhost/aliendb';
const  mongoose= require('mongoose')
mongoose.connect('mongodb://localhost/aliendb')
  .then(() => console.log('MongoDB connected...'))
  .catch(err => console.error('MongoDB connection error:', err));
const con=mongoose.connection
con.on('open', function(){
    console.log('connected to database')
})
app.use(express.json())
const alienR=require('./routers/aliens')
app.use('/aliens',alienR)
app.listen(9000, function(){
    console.log('server started')})