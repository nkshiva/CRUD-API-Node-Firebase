const express = require('express');
const router = express.Router();
const Alien = require('../models/alien');

// Handle GET request for /aliens
router.get('/', async(req, res) => {
    try {
        const aliens = await Alien.find();
        res.json(aliens);
    } catch (err) {
        res.status(500).send('Error: ' + err);
    }
});

// Get alien by ID
router.get('/:id', async(req, res) => {
    try {
        const alien = await Alien.findById(req.params.id);
        res.json(alien);
    } catch (err) {
        res.status(500).send('Error: ' + err);
    }
});

// POST route (Create alien)
router.post('/', async(req, res) => {
    const alien = new Alien({
        name: req.body.name,
        tech: req.body.tech,
        sub: req.body.sub
    });
    try {
        const al = await alien.save();
        res.json(al);
    } catch (err) {
        res.status(500).send('Error: ' + err);
    }
});

// PATCH route (Update alien)
router.patch('/:id', async(req, res) => {
    try {
        const alien = await Alien.findById(req.params.id);
        alien.sub = req.body.sub;
        const updatedAlien = await alien.save();
        res.json(updatedAlien);
    } catch (err) {
        res.status(500).send('Error: ' + err);
    }
});

// DELETE route (Remove alien)
router.delete('/:id', async(req, res) => {
    try {
        const alien = await Alien.findById(req.params.id);
        await alien.deleteOne();
        res.json({ message: 'Alien deleted' });
    } catch (err) {
        res.status(500).send('Error: ' + err);
    }
});

module.exports = router;
